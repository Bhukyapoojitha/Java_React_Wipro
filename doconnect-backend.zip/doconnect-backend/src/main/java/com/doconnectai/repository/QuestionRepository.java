package com.doconnectai.repository;

import com.doconnectai.entity.Question;
import com.doconnectai.entity.Question.QuestionStatus;
import com.doconnectai.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface QuestionRepository extends JpaRepository<Question, Long> {
    Page<Question> findByAuthor(User author, Pageable pageable);
    Page<Question> findByStatus(QuestionStatus status, Pageable pageable);
    Page<Question> findByTagsContainingIgnoreCase(String tag, Pageable pageable);

    @Query("SELECT q FROM Question q WHERE " +
           "LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(q.content) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<Question> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    long countByAuthor(User author);
}
