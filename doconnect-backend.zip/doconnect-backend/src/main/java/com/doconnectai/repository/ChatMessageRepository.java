package com.doconnectai.repository;

import com.doconnectai.entity.ChatMessage;
import com.doconnectai.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findBySessionIdOrderByCreatedAtAsc(String sessionId);
    Page<ChatMessage> findBySender(User sender, Pageable pageable);
    void deleteBySessionId(String sessionId);
}
