package com.doconnectai.repository;

import com.doconnectai.entity.Answer;
import com.doconnectai.entity.Question;
import com.doconnectai.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AnswerRepository extends JpaRepository<Answer, Long> {
    Page<Answer> findByQuestion(Question question, Pageable pageable);
    List<Answer> findByQuestionOrderByVoteCountDescCreatedAtAsc(Question question);
    Page<Answer> findByAuthor(User author, Pageable pageable);
    Optional<Answer> findByQuestionAndAcceptedTrue(Question question);
    long countByAuthor(User author);
    long countByQuestion(Question question);
}
