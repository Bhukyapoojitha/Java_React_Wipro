package com.doconnectai.controller;

import com.doconnectai.service.AnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
@Tag(name = "Analytics")
@SecurityRequirement(name = "bearerAuth")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/platform")
    @Operation(summary = "Get overall platform statistics")
    public ResponseEntity<Map<String, Object>> platformStats() {
        return ResponseEntity.ok(analyticsService.getPlatformStats());
    }

    @GetMapping("/user/{username}")
    @Operation(summary = "Get statistics for a specific user")
    public ResponseEntity<Map<String, Object>> userStats(@PathVariable String username) {
        return ResponseEntity.ok(analyticsService.getUserStats(username));
    }

    @GetMapping("/top-contributors")
    @Operation(summary = "Get top contributors")
    public ResponseEntity<Map<String, Object>> topContributors(
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(analyticsService.getTopContributors(limit));
    }
}
