package com.doconnectai.controller;

import com.doconnectai.dto.QuestionDTO;
import com.doconnectai.service.QuestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Questions")
@SecurityRequirement(name = "bearerAuth")
public class QuestionController {

    private final QuestionService questionService;

    @PostMapping
    @Operation(summary = "Create a new question")
    public ResponseEntity<QuestionDTO> create(@Valid @RequestBody QuestionDTO dto, Authentication auth) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(questionService.createQuestion(dto, auth.getName()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get question by ID")
    public ResponseEntity<QuestionDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(questionService.getQuestionById(id));
    }

    @GetMapping
    @Operation(summary = "Get all questions (paginated)")
    public ResponseEntity<Page<QuestionDTO>> getAll(@PageableDefault(size = 10, sort = "createdAt") Pageable pageable) {
        return ResponseEntity.ok(questionService.getAllQuestions(pageable));
    }

    @GetMapping("/search")
    @Operation(summary = "Search questions by keyword")
    public ResponseEntity<Page<QuestionDTO>> search(@RequestParam String keyword,
                                                     @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(questionService.searchQuestions(keyword, pageable));
    }

    @GetMapping("/tag/{tag}")
    @Operation(summary = "Get questions by tag")
    public ResponseEntity<Page<QuestionDTO>> getByTag(@PathVariable String tag,
                                                       @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(questionService.getQuestionsByTag(tag, pageable));
    }

    @GetMapping("/user/{username}")
    @Operation(summary = "Get questions by user")
    public ResponseEntity<Page<QuestionDTO>> getByUser(@PathVariable String username,
                                                        @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(questionService.getQuestionsByUser(username, pageable));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a question")
    public ResponseEntity<QuestionDTO> update(@PathVariable Long id,
                                               @Valid @RequestBody QuestionDTO dto,
                                               Authentication auth) {
        return ResponseEntity.ok(questionService.updateQuestion(id, dto, auth.getName()));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a question")
    public ResponseEntity<Void> delete(@PathVariable Long id, Authentication auth) {
        questionService.deleteQuestion(id, auth.getName());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/vote")
    @Operation(summary = "Vote on a question (+1 or -1)")
    public ResponseEntity<QuestionDTO> vote(@PathVariable Long id,
                                             @RequestParam int vote,
                                             Authentication auth) {
        return ResponseEntity.ok(questionService.voteQuestion(id, vote, auth.getName()));
    }
}
