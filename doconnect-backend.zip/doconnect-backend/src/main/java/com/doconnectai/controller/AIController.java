package com.doconnectai.controller;

import com.doconnectai.dto.AIRequestDTO;
import com.doconnectai.service.AIService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
@Tag(name = "AI")
@SecurityRequirement(name = "bearerAuth")
public class AIController {

    private final AIService aiService;

    @PostMapping("/generate")
    @Operation(summary = "Generate an AI-powered answer")
    public ResponseEntity<Map<String, String>> generate(@Valid @RequestBody AIRequestDTO request) {
        String response = aiService.generateAnswer(request);
        return ResponseEntity.ok(Map.of("response", response));
    }

    @GetMapping("/summarize/{questionId}")
    @Operation(summary = "Summarize a question using AI")
    public ResponseEntity<Map<String, String>> summarize(@PathVariable Long questionId) {
        return ResponseEntity.ok(Map.of("summary", aiService.summarizeQuestion(questionId)));
    }
}
