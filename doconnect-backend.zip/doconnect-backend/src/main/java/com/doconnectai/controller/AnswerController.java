package com.doconnectai.controller;

import com.doconnectai.dto.AnswerDTO;
import com.doconnectai.service.AnswerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/answers")
@RequiredArgsConstructor
@Tag(name = "Answers")
@SecurityRequirement(name = "bearerAuth")
public class AnswerController {

    private final AnswerService answerService;

    @PostMapping("/question/{questionId}")
    @Operation(summary = "Post an answer to a question")
    public ResponseEntity<AnswerDTO> create(@PathVariable Long questionId,
                                             @Valid @RequestBody AnswerDTO dto,
                                             Authentication auth) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(answerService.createAnswer(questionId, dto, auth.getName()));
    }

    @GetMapping("/question/{questionId}")
    @Operation(summary = "Get all answers for a question")
    public ResponseEntity<List<AnswerDTO>> getByQuestion(@PathVariable Long questionId) {
        return ResponseEntity.ok(answerService.getAnswersByQuestion(questionId));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an answer")
    public ResponseEntity<AnswerDTO> update(@PathVariable Long id,
                                             @Valid @RequestBody AnswerDTO dto,
                                             Authentication auth) {
        return ResponseEntity.ok(answerService.updateAnswer(id, dto, auth.getName()));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an answer")
    public ResponseEntity<Void> delete(@PathVariable Long id, Authentication auth) {
        answerService.deleteAnswer(id, auth.getName());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/vote")
    @Operation(summary = "Vote on an answer (+1 or -1)")
    public ResponseEntity<AnswerDTO> vote(@PathVariable Long id,
                                           @RequestParam int vote,
                                           Authentication auth) {
        return ResponseEntity.ok(answerService.voteAnswer(id, vote, auth.getName()));
    }

    @PostMapping("/{id}/accept")
    @Operation(summary = "Accept an answer (question author only)")
    public ResponseEntity<AnswerDTO> accept(@PathVariable Long id, Authentication auth) {
        return ResponseEntity.ok(answerService.acceptAnswer(id, auth.getName()));
    }
}
