package com.doconnectai.controller;

import com.doconnectai.entity.ChatMessage;
import com.doconnectai.service.ChatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@Tag(name = "Chat")
@SecurityRequirement(name = "bearerAuth")
public class ChatController {

    private final ChatService chatService;

    @PostMapping("/send")
    @Operation(summary = "Send a chat message")
    public ResponseEntity<ChatMessage> send(@RequestBody Map<String, String> body,
                                             Authentication auth) {
        return ResponseEntity.ok(chatService.sendMessage(
                body.get("content"),
                body.get("sessionId"),
                auth.getName()
        ));
    }

    @GetMapping("/history/{sessionId}")
    @Operation(summary = "Get chat history by session ID")
    public ResponseEntity<List<ChatMessage>> getHistory(@PathVariable String sessionId) {
        return ResponseEntity.ok(chatService.getChatHistory(sessionId));
    }

    @DeleteMapping("/clear/{sessionId}")
    @Operation(summary = "Clear chat history for a session")
    public ResponseEntity<Void> clear(@PathVariable String sessionId) {
        chatService.clearChat(sessionId);
        return ResponseEntity.noContent().build();
    }
}
