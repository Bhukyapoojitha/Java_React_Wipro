package com.doconnectai.dto;

import com.doconnectai.entity.Question.QuestionStatus;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class QuestionDTO {

    private Long id;

    @NotBlank(message = "Title is required")
    @Size(min = 10, max = 255, message = "Title must be between 10 and 255 characters")
    private String title;

    @NotBlank(message = "Content is required")
    @Size(min = 20, message = "Content must be at least 20 characters")
    private String content;

    @Size(max = 500, message = "Tags cannot exceed 500 characters")
    private String tags;

    private Integer viewCount;
    private Integer voteCount;
    private QuestionStatus status;
    private String authorUsername;
    private Long authorId;
    private int answerCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
