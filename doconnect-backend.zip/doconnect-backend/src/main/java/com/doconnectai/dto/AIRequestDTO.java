package com.doconnectai.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AIRequestDTO {

    @NotBlank(message = "Prompt is required")
    @Size(min = 3, max = 2000, message = "Prompt must be between 3 and 2000 characters")
    private String prompt;

    private String sessionId;

    @Min(value = 100, message = "Max tokens must be at least 100")
    @Max(value = 4000, message = "Max tokens cannot exceed 4000")
    private Integer maxTokens = 500;
}
