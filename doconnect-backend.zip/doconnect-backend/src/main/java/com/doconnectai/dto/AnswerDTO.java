package com.doconnectai.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AnswerDTO {

    private Long id;

    @NotBlank(message = "Content is required")
    @Size(min = 10, message = "Answer must be at least 10 characters")
    private String content;

    private Integer voteCount;
    private Boolean accepted;
    private Long questionId;
    private String authorUsername;
    private Long authorId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
