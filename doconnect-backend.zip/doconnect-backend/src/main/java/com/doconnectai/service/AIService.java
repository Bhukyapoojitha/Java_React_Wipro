package com.doconnectai.service;

import com.doconnectai.dto.AIRequestDTO;

public interface AIService {
    String generateAnswer(AIRequestDTO request);
    String summarizeQuestion(Long questionId);
}
