package com.doconnectai.service;

import com.doconnectai.dto.QuestionDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface QuestionService {
    QuestionDTO createQuestion(QuestionDTO dto, String username);
    QuestionDTO getQuestionById(Long id);
    Page<QuestionDTO> getAllQuestions(Pageable pageable);
    Page<QuestionDTO> searchQuestions(String keyword, Pageable pageable);
    Page<QuestionDTO> getQuestionsByTag(String tag, Pageable pageable);
    Page<QuestionDTO> getQuestionsByUser(String username, Pageable pageable);
    QuestionDTO updateQuestion(Long id, QuestionDTO dto, String username);
    void deleteQuestion(Long id, String username);
    QuestionDTO voteQuestion(Long id, int vote, String username);
}
