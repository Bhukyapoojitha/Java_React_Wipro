package com.doconnectai.service;

import com.doconnectai.entity.ChatMessage;
import java.util.List;

public interface ChatService {
    ChatMessage sendMessage(String content, String sessionId, String username);
    List<ChatMessage> getChatHistory(String sessionId);
    void clearChat(String sessionId);
}
