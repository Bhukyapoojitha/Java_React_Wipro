package com.doconnectai.service.impl;

import com.doconnectai.dto.QuestionDTO;
import com.doconnectai.entity.Question;
import com.doconnectai.entity.User;
import com.doconnectai.exception.ResourceNotFoundException;
import com.doconnectai.repository.AnswerRepository;
import com.doconnectai.repository.QuestionRepository;
import com.doconnectai.repository.UserRepository;
import com.doconnectai.service.QuestionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class QuestionServiceImpl implements QuestionService {

    private final QuestionRepository questionRepository;
    private final UserRepository userRepository;
    private final AnswerRepository answerRepository;

    @Override
    @Transactional
    public QuestionDTO createQuestion(QuestionDTO dto, String username) {
        log.info("Creating question for user: {}", username);
        User author = findUser(username);
        Question question = Question.builder()
                .title(dto.getTitle())
                .content(dto.getContent())
                .tags(dto.getTags())
                .author(author)
                .build();
        return toDTO(questionRepository.save(question));
    }

    @Override
    @Transactional
    public QuestionDTO getQuestionById(Long id) {
        Question question = findQuestion(id);
        question.setViewCount(question.getViewCount() + 1);
        return toDTO(questionRepository.save(question));
    }

    @Override
    public Page<QuestionDTO> getAllQuestions(Pageable pageable) {
        return questionRepository.findAll(pageable).map(this::toDTO);
    }

    @Override
    public Page<QuestionDTO> searchQuestions(String keyword, Pageable pageable) {
        return questionRepository.searchByKeyword(keyword, pageable).map(this::toDTO);
    }

    @Override
    public Page<QuestionDTO> getQuestionsByTag(String tag, Pageable pageable) {
        return questionRepository.findByTagsContainingIgnoreCase(tag, pageable).map(this::toDTO);
    }

    @Override
    public Page<QuestionDTO> getQuestionsByUser(String username, Pageable pageable) {
        User user = findUser(username);
        return questionRepository.findByAuthor(user, pageable).map(this::toDTO);
    }

    @Override
    @Transactional
    public QuestionDTO updateQuestion(Long id, QuestionDTO dto, String username) {
        Question question = findQuestion(id);
        verifyOwnership(question.getAuthor().getUsername(), username);
        question.setTitle(dto.getTitle());
        question.setContent(dto.getContent());
        question.setTags(dto.getTags());
        log.info("Updated question id: {}", id);
        return toDTO(questionRepository.save(question));
    }

    @Override
    @Transactional
    public void deleteQuestion(Long id, String username) {
        Question question = findQuestion(id);
        verifyOwnership(question.getAuthor().getUsername(), username);
        questionRepository.delete(question);
        log.info("Deleted question id: {}", id);
    }

    @Override
    @Transactional
    public QuestionDTO voteQuestion(Long id, int vote, String username) {
        Question question = findQuestion(id);
        question.setVoteCount(question.getVoteCount() + vote);
        return toDTO(questionRepository.save(question));
    }

    private Question findQuestion(Long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id: " + id));
    }

    private User findUser(String username) {
        return userRepository.findByUsernameOrEmail(username, username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private void verifyOwnership(String ownerUsername, String requestingUsername) {
        if (!ownerUsername.equals(requestingUsername)) {
            throw new AccessDeniedException("You do not have permission to modify this resource");
        }
    }

    private QuestionDTO toDTO(Question q) {
        QuestionDTO dto = new QuestionDTO();
        dto.setId(q.getId());
        dto.setTitle(q.getTitle());
        dto.setContent(q.getContent());
        dto.setTags(q.getTags());
        dto.setViewCount(q.getViewCount());
        dto.setVoteCount(q.getVoteCount());
        dto.setStatus(q.getStatus());
        dto.setAuthorUsername(q.getAuthor().getUsername());
        dto.setAuthorId(q.getAuthor().getId());
        dto.setAnswerCount((int) answerRepository.countByQuestion(q));
        dto.setCreatedAt(q.getCreatedAt());
        dto.setUpdatedAt(q.getUpdatedAt());
        return dto;
    }
}
