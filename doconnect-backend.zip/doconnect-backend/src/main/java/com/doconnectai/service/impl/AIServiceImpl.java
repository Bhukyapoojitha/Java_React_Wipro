package com.doconnectai.service.impl;

import com.doconnectai.dto.AIRequestDTO;
import com.doconnectai.exception.ResourceNotFoundException;
import com.doconnectai.repository.QuestionRepository;
import com.doconnectai.service.AIService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AIServiceImpl implements AIService {

    private final QuestionRepository questionRepository;

    @Override
    public String generateAnswer(AIRequestDTO request) {
        log.info("Generating AI answer for prompt (session: {})", request.getSessionId());
        // TODO: integrate with OpenAI / custom AI model via RestTemplate or WebClient
        // For now, returns a placeholder response
        return "AI Response: Based on your question about '" + request.getPrompt() +
               "', here is a generated answer. (Connect your AI provider in AIServiceImpl)";
    }

    @Override
    public String summarizeQuestion(Long questionId) {
        var question = questionRepository.findById(questionId)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found: " + questionId));
        log.info("Summarizing question id: {}", questionId);
        return "Summary of: " + question.getTitle() + " - " + question.getContent().substring(0, Math.min(200, question.getContent().length())) + "...";
    }
}
