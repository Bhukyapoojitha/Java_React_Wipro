package com.doconnectai.service;

import com.doconnectai.dto.AnswerDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

public interface AnswerService {
    AnswerDTO createAnswer(Long questionId, AnswerDTO dto, String username);
    AnswerDTO getAnswerById(Long id);
    List<AnswerDTO> getAnswersByQuestion(Long questionId);
    Page<AnswerDTO> getAnswersByUser(String username, Pageable pageable);
    AnswerDTO updateAnswer(Long id, AnswerDTO dto, String username);
    void deleteAnswer(Long id, String username);
    AnswerDTO voteAnswer(Long id, int vote, String username);
    AnswerDTO acceptAnswer(Long id, String username);
}
