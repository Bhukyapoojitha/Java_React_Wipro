package com.doconnectai.service.impl;

import com.doconnectai.entity.User;
import com.doconnectai.exception.ResourceNotFoundException;
import com.doconnectai.repository.AnswerRepository;
import com.doconnectai.repository.QuestionRepository;
import com.doconnectai.repository.UserRepository;
import com.doconnectai.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AnalyticsServiceImpl implements AnalyticsService {

    private final UserRepository userRepository;
    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;

    @Override
    public Map<String, Object> getPlatformStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalUsers", userRepository.count());
        stats.put("totalQuestions", questionRepository.count());
        stats.put("totalAnswers", answerRepository.count());
        log.debug("Platform stats fetched");
        return stats;
    }

    @Override
    public Map<String, Object> getUserStats(String username) {
        User user = userRepository.findByUsernameOrEmail(username, username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
        Map<String, Object> stats = new HashMap<>();
        stats.put("questionsAsked", questionRepository.countByAuthor(user));
        stats.put("answersGiven", answerRepository.countByAuthor(user));
        stats.put("memberSince", user.getCreatedAt());
        return stats;
    }

    @Override
    public Map<String, Object> getTopContributors(int limit) {
        List<User> users = userRepository.findAll(PageRequest.of(0, limit)).getContent();
        List<Map<String, Object>> contributors = users.stream().map(u -> {
            Map<String, Object> entry = new HashMap<>();
            entry.put("username", u.getUsername());
            entry.put("answers", answerRepository.countByAuthor(u));
            entry.put("questions", questionRepository.countByAuthor(u));
            return entry;
        }).collect(Collectors.toList());
        Map<String, Object> result = new HashMap<>();
        result.put("contributors", contributors);
        return result;
    }
}
