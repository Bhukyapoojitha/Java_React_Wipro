package com.doconnectai.service;

import java.util.Map;

public interface AnalyticsService {
    Map<String, Object> getPlatformStats();
    Map<String, Object> getUserStats(String username);
    Map<String, Object> getTopContributors(int limit);
}
