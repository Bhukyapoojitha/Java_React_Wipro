package com.doconnectai.service;

import com.doconnectai.dto.AuthResponse;
import com.doconnectai.dto.LoginRequest;
import com.doconnectai.dto.RegisterRequest;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}
