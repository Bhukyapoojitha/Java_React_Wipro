package com.doconnectai.service.impl;

import com.doconnectai.entity.ChatMessage;
import com.doconnectai.entity.User;
import com.doconnectai.repository.ChatMessageRepository;
import com.doconnectai.repository.UserRepository;
import com.doconnectai.service.ChatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChatServiceImpl implements ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ChatMessage sendMessage(String content, String sessionId, String username) {
        User sender = userRepository.findByUsernameOrEmail(username, username).orElse(null);
        ChatMessage message = ChatMessage.builder()
                .content(content)
                .sessionId(sessionId)
                .sender(sender)
                .type(ChatMessage.MessageType.USER)
                .build();
        chatMessageRepository.save(message);
        log.info("Saved chat message for session: {}", sessionId);
        return message;
    }

    @Override
    public List<ChatMessage> getChatHistory(String sessionId) {
        return chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(sessionId);
    }

    @Override
    @Transactional
    public void clearChat(String sessionId) {
        chatMessageRepository.deleteBySessionId(sessionId);
        log.info("Cleared chat history for session: {}", sessionId);
    }
}
