package com.doconnectai.service.impl;

import com.doconnectai.dto.AnswerDTO;
import com.doconnectai.entity.Answer;
import com.doconnectai.entity.Question;
import com.doconnectai.entity.User;
import com.doconnectai.exception.ResourceNotFoundException;
import com.doconnectai.repository.AnswerRepository;
import com.doconnectai.repository.QuestionRepository;
import com.doconnectai.repository.UserRepository;
import com.doconnectai.service.AnswerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AnswerServiceImpl implements AnswerService {

    private final AnswerRepository answerRepository;
    private final QuestionRepository questionRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public AnswerDTO createAnswer(Long questionId, AnswerDTO dto, String username) {
        log.info("Creating answer for question {} by user {}", questionId, username);
        Question question = findQuestion(questionId);
        User author = findUser(username);
        Answer answer = Answer.builder()
                .content(dto.getContent())
                .question(question)
                .author(author)
                .build();
        return toDTO(answerRepository.save(answer));
    }

    @Override
    public AnswerDTO getAnswerById(Long id) {
        return toDTO(findAnswer(id));
    }

    @Override
    public List<AnswerDTO> getAnswersByQuestion(Long questionId) {
        Question question = findQuestion(questionId);
        return answerRepository.findByQuestionOrderByVoteCountDescCreatedAtAsc(question)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    public Page<AnswerDTO> getAnswersByUser(String username, Pageable pageable) {
        User user = findUser(username);
        return answerRepository.findByAuthor(user, pageable).map(this::toDTO);
    }

    @Override
    @Transactional
    public AnswerDTO updateAnswer(Long id, AnswerDTO dto, String username) {
        Answer answer = findAnswer(id);
        verifyOwnership(answer.getAuthor().getUsername(), username);
        answer.setContent(dto.getContent());
        log.info("Updated answer id: {}", id);
        return toDTO(answerRepository.save(answer));
    }

    @Override
    @Transactional
    public void deleteAnswer(Long id, String username) {
        Answer answer = findAnswer(id);
        verifyOwnership(answer.getAuthor().getUsername(), username);
        answerRepository.delete(answer);
        log.info("Deleted answer id: {}", id);
    }

    @Override
    @Transactional
    public AnswerDTO voteAnswer(Long id, int vote, String username) {
        Answer answer = findAnswer(id);
        answer.setVoteCount(answer.getVoteCount() + vote);
        return toDTO(answerRepository.save(answer));
    }

    @Override
    @Transactional
    public AnswerDTO acceptAnswer(Long id, String username) {
        Answer answer = findAnswer(id);
        Question question = answer.getQuestion();
        verifyOwnership(question.getAuthor().getUsername(), username);

        // Unaccept previously accepted answer
        answerRepository.findByQuestionAndAcceptedTrue(question)
                .ifPresent(prev -> { prev.setAccepted(false); answerRepository.save(prev); });

        answer.setAccepted(true);
        question.setStatus(Question.QuestionStatus.ANSWERED);
        questionRepository.save(question);
        log.info("Accepted answer id: {} for question id: {}", id, question.getId());
        return toDTO(answerRepository.save(answer));
    }

    private Answer findAnswer(Long id) {
        return answerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Answer not found with id: " + id));
    }

    private Question findQuestion(Long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id: " + id));
    }

    private User findUser(String username) {
        return userRepository.findByUsernameOrEmail(username, username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private void verifyOwnership(String owner, String requester) {
        if (!owner.equals(requester)) {
            throw new AccessDeniedException("You do not have permission to modify this resource");
        }
    }

    private AnswerDTO toDTO(Answer a) {
        AnswerDTO dto = new AnswerDTO();
        dto.setId(a.getId());
        dto.setContent(a.getContent());
        dto.setVoteCount(a.getVoteCount());
        dto.setAccepted(a.getAccepted());
        dto.setQuestionId(a.getQuestion().getId());
        dto.setAuthorUsername(a.getAuthor().getUsername());
        dto.setAuthorId(a.getAuthor().getId());
        dto.setCreatedAt(a.getCreatedAt());
        dto.setUpdatedAt(a.getUpdatedAt());
        return dto;
    }
}
