package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Branch;
import com.wipro.BankManagementSystem.exception.ResourceNotFoundException;
import com.wipro.BankManagementSystem.repository.BranchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BranchServiceImpl implements IBranchService {

    @Autowired
    private BranchRepository branchRepository;

    @Override
    public Branch saveBranch(Branch branch) {
        if (branchRepository.existsByBranchName(branch.getBranchName()))
            throw new RuntimeException("Branch already exists with name: " + branch.getBranchName());
        return branchRepository.save(branch);
    }

    @Override
    public List<Branch> getAllBranches() {
        return branchRepository.findAll();
    }

    @Override
    public Branch getBranchById(Long id) {
        return branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Branch not found with ID: " + id));
    }

    @Override
    public Branch updateBranch(Long id, Branch branch) {
        Branch existing = getBranchById(id);
        existing.setBranchName(branch.getBranchName());
        existing.setBranchLocation(branch.getBranchLocation());
        return branchRepository.save(existing);
    }

    @Override
    public void deleteBranch(Long id) {
        Branch branch = getBranchById(id);
        branchRepository.delete(branch);
    }
}
