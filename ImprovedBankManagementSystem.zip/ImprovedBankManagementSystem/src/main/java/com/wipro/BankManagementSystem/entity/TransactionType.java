package com.wipro.BankManagementSystem.entity;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    TRANSFER,
    CREDIT,
    DEBIT
}