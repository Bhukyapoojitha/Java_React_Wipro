package com.wipro.BankManagementSystem.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BranchDTO {
    private Long branchId;
    private String branchName;
    private String branchLocation;
}
