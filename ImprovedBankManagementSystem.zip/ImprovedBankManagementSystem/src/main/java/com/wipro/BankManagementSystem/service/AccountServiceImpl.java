package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Account;
import com.wipro.BankManagementSystem.entity.Transaction;
import com.wipro.BankManagementSystem.exception.ResourceNotFoundException;
import com.wipro.BankManagementSystem.repository.AccountRepository;
import com.wipro.BankManagementSystem.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class AccountServiceImpl implements IAccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public Account saveAccount(Account account) {
        return accountRepository.save(account);
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    @Override
    public Account getAccountById(Long id) {
        return accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Account not found with ID: " + id));
    }

    @Override
    public Account updateAccount(Long id, Account account) {
        Account existing = getAccountById(id);
        existing.setAccountType(account.getAccountType());
        existing.setBalance(account.getBalance());
        return accountRepository.save(existing);
    }

    @Override
    public void deleteAccount(Long id) {
        Account account = getAccountById(id);
        accountRepository.delete(account);
    }

    @Override
    @Transactional
    public Account deposit(Long id, double amount) {
        if (amount <= 0) throw new RuntimeException("Deposit amount must be greater than zero");
        Account account = getAccountById(id);
        account.setBalance(account.getBalance() + amount);

        Transaction txn = new Transaction();
        txn.setTransactionType("DEPOSIT");
        txn.setAmount(amount);
        txn.setTransactionDate(LocalDate.now());
        txn.setAccount(account);
        transactionRepository.save(txn);

        return accountRepository.save(account);
    }

    @Override
    @Transactional
    public Account withdraw(Long id, double amount) {
        if (amount <= 0) throw new RuntimeException("Withdrawal amount must be greater than zero");
        Account account = getAccountById(id);
        if (account.getBalance() < amount)
            throw new RuntimeException("Insufficient balance. Available: " + account.getBalance());
        account.setBalance(account.getBalance() - amount);

        Transaction txn = new Transaction();
        txn.setTransactionType("WITHDRAWAL");
        txn.setAmount(amount);
        txn.setTransactionDate(LocalDate.now());
        txn.setAccount(account);
        transactionRepository.save(txn);

        return accountRepository.save(account);
    }

    @Override
    public List<Account> getAccountsByCustomerId(Long customerId) {
        return accountRepository.findByCustomer_CustomerId(customerId);
    }
}
