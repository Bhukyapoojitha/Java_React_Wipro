package com.wipro.BankManagementSystem.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountDTO {
    private Long accountId;
    private String accountType;
    private double balance;
    private Long customerId;
}
