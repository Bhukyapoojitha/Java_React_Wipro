package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Branch;

import java.util.List;

public interface IBranchService {
    Branch saveBranch(Branch branch);
    List<Branch> getAllBranches();
    Branch getBranchById(Long id);
    Branch updateBranch(Long id, Branch branch);
    void deleteBranch(Long id);
}
