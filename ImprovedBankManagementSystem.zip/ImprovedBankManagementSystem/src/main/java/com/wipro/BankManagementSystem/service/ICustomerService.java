package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Customer;

import java.util.List;

public interface ICustomerService {
    Customer saveCustomer(Customer customer);
    List<Customer> getAllCustomers();
    Customer getCustomerById(Long id);
    Customer updateCustomer(Long id, Customer customer);
    void deleteCustomer(Long id);
    Customer getCustomerByEmail(String email);
    List<Customer> getCustomersByBranchId(Long branchId);
}
