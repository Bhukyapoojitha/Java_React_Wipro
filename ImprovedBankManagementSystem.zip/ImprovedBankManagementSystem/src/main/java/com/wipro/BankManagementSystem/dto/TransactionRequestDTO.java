package com.wipro.BankManagementSystem.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class TransactionRequestDTO {
    private Long sourceAccountId;
    private Long targetAccountId;
    private BigDecimal amount;
    private String remarks;
}