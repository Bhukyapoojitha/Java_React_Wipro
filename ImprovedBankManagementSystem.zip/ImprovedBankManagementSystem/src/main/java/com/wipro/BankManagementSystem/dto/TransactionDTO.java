package com.wipro.BankManagementSystem.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDTO {
    private Long transactionId;
    private String transactionType;
    private double amount;
    private LocalDate transactionDate;
    private Long accountId;
}
