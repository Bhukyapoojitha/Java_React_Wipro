package com.wipro.BankManagementSystem.controller;

import com.wipro.BankManagementSystem.entity.Branch;
import com.wipro.BankManagementSystem.service.IBranchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/branch")
@Tag(name = "Branch Controller", description = "APIs for Branch Management")
public class BranchRestController {

    @Autowired
    private IBranchService branchService;

    @PostMapping
    @Operation(summary = "Create a new branch")
    public ResponseEntity<Branch> saveBranch(@Valid @RequestBody Branch branch) {
        return new ResponseEntity<>(branchService.saveBranch(branch), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all branches")
    public ResponseEntity<List<Branch>> getAllBranches() {
        return ResponseEntity.ok(branchService.getAllBranches());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get branch by ID")
    public ResponseEntity<Branch> getBranchById(@PathVariable Long id) {
        return ResponseEntity.ok(branchService.getBranchById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update branch by ID")
    public ResponseEntity<Branch> updateBranch(
            @PathVariable Long id,
            @Valid @RequestBody Branch branch) {
        return ResponseEntity.ok(branchService.updateBranch(id, branch));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete branch by ID")
    public ResponseEntity<String> deleteBranch(@PathVariable Long id) {
        branchService.deleteBranch(id);
        return ResponseEntity.ok("Branch deleted successfully");
    }
}
