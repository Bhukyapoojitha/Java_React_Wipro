package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Transaction;

import java.time.LocalDate;
import java.util.List;

public interface ITransactionService {
    Transaction saveTransaction(Transaction transaction);
    List<Transaction> getAllTransactions();
    Transaction getTransactionById(Long id);
    void deleteTransaction(Long id);
    List<Transaction> getTransactionsByAccountId(Long accountId);
    List<Transaction> getTransactionsByDateRange(LocalDate startDate, LocalDate endDate);
}
