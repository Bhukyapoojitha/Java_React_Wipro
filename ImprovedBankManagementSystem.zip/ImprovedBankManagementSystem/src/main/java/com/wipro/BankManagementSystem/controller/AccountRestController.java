package com.wipro.BankManagementSystem.controller;

import com.wipro.BankManagementSystem.entity.Account;
import com.wipro.BankManagementSystem.service.IAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
@Tag(name = "Account Controller", description = "APIs for Account Management")
public class AccountRestController {

    @Autowired
    private IAccountService accountService;

    @PostMapping
    @Operation(summary = "Create a new account")
    public ResponseEntity<Account> saveAccount(@Valid @RequestBody Account account) {
        return new ResponseEntity<>(accountService.saveAccount(account), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all accounts")
    public ResponseEntity<List<Account>> getAllAccounts() {
        return ResponseEntity.ok(accountService.getAllAccounts());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get account by ID")
    public ResponseEntity<Account> getAccountById(@PathVariable Long id) {
        return ResponseEntity.ok(accountService.getAccountById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update account by ID")
    public ResponseEntity<Account> updateAccount(
            @PathVariable Long id,
            @Valid @RequestBody Account account) {
        return ResponseEntity.ok(accountService.updateAccount(id, account));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete account by ID")
    public ResponseEntity<String> deleteAccount(@PathVariable Long id) {
        accountService.deleteAccount(id);
        return ResponseEntity.ok("Account deleted successfully");
    }

    @PutMapping("/deposit/{id}/{amount}")
    @Operation(summary = "Deposit amount into account")
    public ResponseEntity<Account> deposit(
            @PathVariable Long id,
            @PathVariable double amount) {
        return ResponseEntity.ok(accountService.deposit(id, amount));
    }

    @PutMapping("/withdraw/{id}/{amount}")
    @Operation(summary = "Withdraw amount from account")
    public ResponseEntity<Account> withdraw(
            @PathVariable Long id,
            @PathVariable double amount) {
        return ResponseEntity.ok(accountService.withdraw(id, amount));
    }

    @GetMapping("/customer/{customerId}")
    @Operation(summary = "Get all accounts by customer ID")
    public ResponseEntity<List<Account>> getAccountsByCustomerId(@PathVariable Long customerId) {
        return ResponseEntity.ok(accountService.getAccountsByCustomerId(customerId));
    }
}
