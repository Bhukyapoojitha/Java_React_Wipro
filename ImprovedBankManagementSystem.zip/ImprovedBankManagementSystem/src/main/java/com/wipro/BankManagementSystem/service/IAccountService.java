package com.wipro.BankManagementSystem.service;

import com.wipro.BankManagementSystem.entity.Account;

import java.util.List;

public interface IAccountService {
    Account saveAccount(Account account);
    List<Account> getAllAccounts();
    Account getAccountById(Long id);
    Account updateAccount(Long id, Account account);
    void deleteAccount(Long id);
    Account deposit(Long id, double amount);
    Account withdraw(Long id, double amount);
    List<Account> getAccountsByCustomerId(Long customerId);
}
