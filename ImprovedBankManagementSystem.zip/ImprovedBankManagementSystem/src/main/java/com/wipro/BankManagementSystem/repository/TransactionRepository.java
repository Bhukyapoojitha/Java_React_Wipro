package com.wipro.BankManagementSystem.repository;

import com.wipro.BankManagementSystem.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccount_AccountId(Long accountId);
    List<Transaction> findByTransactionDateBetween(LocalDate startDate, LocalDate endDate);
}
