# Improved Bank Management System

## Features
- Linked Customer -> Account -> Transaction relationship
- Branch wise account management
- Deposit API
- Withdraw API
- Transfer API
- Transaction history
- DTO based architecture
- Swagger integration
- Exception handling
- Filtering accounts by account type
- No delete API for transactions

## Tech Stack
- Spring Boot
- Spring Data JPA
- MySQL
- Lombok
- Swagger
- DTO Pattern

## Swagger
http://localhost:8080/swagger-ui.html